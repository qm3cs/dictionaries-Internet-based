# 字典收集记录：
[3had0w师傅的mysql字典](https://github.com/3had0w/Fuzzing-Dicts/blob/master/MySQL-Password%EF%BC%883050%EF%BC%89.txt)去重后收录2791个
