generate-tomcat-user:pass.py：读取user.txt和pass.txt并生成符合tomcat验证时的格式user:pass

# 字典收集记录：
magicming200师傅的[tomcat-username字典](https://github.com/magicming200/tomcat-weak-password-scanner/blob/master/username.txt)和[tomcat-password字典](https://github.com/magicming200/tomcat-weak-password-scanner/blob/master/password.txt)去重后收录424个
