# 0x00 项目介绍
本项目专注于收集，整理渗透测试、红队攻击中涉及到的字典

# 0x01 相关优秀项目
https://github.com/rootphantomer/Blasting_dictionary  
https://weakpass.com/  
https://github.com/3had0w/Fuzzing-Dicts  
https://github.com/TheKingOfDuck/fuzzDicts  
https://github.com/danielmiessler/SecLists  
https://github.com/epony4c/Exploit-Dictionary  
https://github.com/c0ny1/upload-fuzz-dic-builder  
https://github.com/gh0stkey/Web-Fuzzing-Box  
[https://github.com/ihebski/DefaultCreds-cheat-sheet](https://github.com/ihebski/DefaultCreds-cheat-sheet)——默认凭证字典

# 0x02 免责声明
该项目仅供授权下使用或学习使用，禁止使用该项目进行违法操作，请各位遵守《中华人民共和国网络安全法》以及相应地方的法律法规，否则自行承担相关责任！
