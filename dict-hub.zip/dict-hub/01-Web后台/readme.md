尝试破解jsp网站文件目录：  
1、https://raw.githubusercontent.com/dustyfresh/dictionaries/master/DirBuster-Lists/directory-list-2.3-medium.txt  
2、dirsearch自带的字典

# 字典收集记录：
[https://download.csdn.net/download/ljp123123ljp/9145013](https://download.csdn.net/download/ljp123123ljp/9145013)收录605个到“中国人姓名-fuzz.txt”

[3had0w师傅的本地文件包含字典](https://github.com/3had0w/Fuzzing-Dicts/blob/master/LFI-Interesting-Files%EF%BC%88249%EF%BC%89.txt)收录222个到“本地文件包含-Linux-fuzz.txt”、27个到“本地文件包含-Windows-fuzz.txt”

[3had0w师傅的网站备份字典](https://github.com/3had0w/Fuzzing-Dicts/blob/master/%E5%85%B6%E5%AE%83%E4%B8%8D%E5%B8%B8%E7%94%A8%E5%A4%87%E4%BB%BD%E6%96%87%E4%BB%B6%E5%AD%97%E5%85%B8%EF%BC%88678%EF%BC%89.txt)经ybdt-dict-cleaner.py去重后，收录3618个到“网站备份-fuzz.txt”

[https://www.iteye.com/resource/h4ck1y-10653176](https://www.iteye.com/resource/h4ck1y-10653176)收录1002个到“网站密码-fuzz.txt”

[3had0w师傅的web目录字典](https://github.com/3had0w/Fuzzing-Dicts/blob/master/%E9%AB%98%E6%95%88%E7%BD%91%E7%AB%99%E5%90%8E%E5%8F%B0%E7%9B%AE%E5%BD%95%E5%AD%97%E5%85%B8%EF%BC%8820101%EF%BC%89.txt)经ybdt-dict-cleaner.py去重后，收录20101个到“网站目录-fuzz.txt”
