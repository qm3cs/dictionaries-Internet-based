### 以下密码是实战中收集到的密码，可根据密码规律，使用白鹿字典生成器生成对应字典，尝试爆破

rdp：  
administrator
<sxkj%0818*web>

mysql：  
root
sxkj0818web

rdp：  
administrator
iZ4i96gbutqraoZ
