# 字典收集记录：
[weakpass项目的ssh字典](https://weakpass.com/wordlist/1847)去重后收录52个
