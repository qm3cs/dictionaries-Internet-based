# 字典收集记录：
[rootphantomer师傅的weblogic字典](https://github.com/rootphantomer/Blasting_dictionary/blob/master/weblogic%E9%BB%98%E8%AE%A4%E5%AF%86%E7%A0%81%E5%88%97%E8%A1%A8.txt)收录8个到“weblogic-fuzz.txt”
